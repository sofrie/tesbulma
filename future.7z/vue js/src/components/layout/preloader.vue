<template>
    <div class="preloader">
        <div class="loader_img"><img src="../../assets/img/loader.gif" alt="loading..." height="64" width="64"></div>
    </div>
</template>
<script>
export default {
    name: 'preloader',
}
</script>
