package com.gdn.scm.bolivia.repo;

import com.gdn.scm.bolivia.entity.LogisticProvider;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created by sofrie.zumaytis on 6/9/2017.
 */
public interface LogisticProviderRepository extends JpaRepository<LogisticProvider, String> {

    public List<LogisticProvider> findByStatus(String status);
}
