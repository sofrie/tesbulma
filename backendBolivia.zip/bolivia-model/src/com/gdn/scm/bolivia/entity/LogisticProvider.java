package com.gdn.scm.bolivia.entity;

import com.gdn.common.base.entity.GdnBaseEntity;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

/**
 * Created by sofrie.zumaytis on 6/9/2017.
 */
@Entity
@Table(name = LogisticProvider.TABLE_NAME)
@Getter
@Setter
public class LogisticProvider extends GdnBaseEntity{

    public static final String TABLE_NAME = "BLV_LOGISTIC_PROVIDER";

    public static final String COLUMN_LOGISTIC_CODE = "LOGISTIC_CODE";
    public static final String COLUMN_LOGISTIC_NAME = "LOGISTIC_NAME";
    public static final String COLUMN_STATUS = "STATUS";
    public static final String COLUMN_DISCOUNT = "DISCOUNT";
    public static final String COLUMN_VAT = "VAT";

    @Column(name = COLUMN_LOGISTIC_CODE, nullable = false)
    private String logisticCode;

    @Column(name = COLUMN_LOGISTIC_NAME, nullable = false)
    private String logisticName;

    @Column(name = COLUMN_STATUS, nullable = false)
    private String status;

    @Column(name = COLUMN_DISCOUNT, nullable = true)
    private Long discount;

    @Column(name = COLUMN_VAT, nullable = true)
    private Long vat;

    public LogisticProvider(String logisticCode, String logisticName, String status, Long discount, Long vat) {
        this.logisticCode = logisticCode;
        this.logisticName = logisticName;
        this.status = status;
        this.discount = discount;
        this.vat = vat;
    }

    public LogisticProvider() {
    }
}
