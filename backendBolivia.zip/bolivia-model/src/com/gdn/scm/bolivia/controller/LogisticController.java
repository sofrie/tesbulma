package com.gdn.scm.bolivia.controller;

import com.gdn.scm.bolivia.entity.LogisticProvider;
import com.gdn.scm.bolivia.repo.LogisticProviderRepository;
import com.gdn.spring.boot.session.Session;
import com.gdn.spring.boot.session.spring.SessionController;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.MediaType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

/**
 * Created by sofrie.zumaytis on 6/9/2017.
 */
@RestController
public class LogisticController implements SessionController {
    @Autowired LogisticProviderRepository logisticProviderRepository;

    public List<LogisticProvider> daftarLogistik = new ArrayList<>();
    public LogisticProvider l = new LogisticProvider();

    @Override
    public boolean isValidSession(Session session) {
        return false;
    }
    @CrossOrigin(origins = "http://localhost:8085")
    @RequestMapping(value = "/api/logisticss", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<LogisticProvider> listlogistik() {
        List<LogisticProvider> response =  Arrays.asList(
                new LogisticProvider("1", "A Logistic", "Active", 5L, 15L),
                new LogisticProvider("2", "B Logistic", "Active", 225L, 1L),
                new LogisticProvider("3", "C Logistic", "Active", 315L, 1L),
                new LogisticProvider("4", "D Logistic", "Inactive", 175L, 1L)
        );
        if (daftarLogistik.size() <= 0) {
            for (int i = 0; i < 4; i++) {
                daftarLogistik.add(response.get(i));
            }
        }
        return response;
    }

    //sort logistic by status
    @CrossOrigin(origins = "http://localhost:8085")
    @RequestMapping(value = "/api/logisticss/{status}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public List<LogisticProvider> sortLogistik(@PathVariable("status") String status) {
//        List<Logistic> sorting=logisticRepository.findByStatus(status);
        List<LogisticProvider> sorting = new ArrayList<>();
        if (status.equals("All")) {
            return daftarLogistik;
        } else {
            return logisticProviderRepository.findByStatus(status);
        }
    }
}
