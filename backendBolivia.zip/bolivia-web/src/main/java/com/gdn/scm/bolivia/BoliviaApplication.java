package com.gdn.scm.bolivia;

import org.springframework.boot.SpringApplication;

/**
 * Created by sofrie.zumaytis on 6/9/2017.
 */
public class BoliviaApplication {

    public static void main(String[] args) {
        SpringApplication.run(BoliviaApplication.class, args);
    }
}
