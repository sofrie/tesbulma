## VuetablePaginationInfo - Properties

### Uses
- [VuetablePaginationInfoMixin](VuetablePaginationInfoMixin)

### Properties

_None_

### Computed

_None_

### Data

_None_

### Methods

_None_

### Events

_None_

