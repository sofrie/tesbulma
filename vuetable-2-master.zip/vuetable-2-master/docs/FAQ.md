## FAQ
- [Background](Background)
- API mode vs. Data mode
- Why my data does not show up? 
- Why the pagination does not show anything? 
- How to specify column width?
- Can Vuetable do the data grouping?
