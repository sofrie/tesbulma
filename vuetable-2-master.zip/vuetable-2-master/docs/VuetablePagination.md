## VuetablePagination

This component contains only the template and utilizes what are available in `VuetablePaginationMixin`.

You can use this component as a guide to create your own pagination component without having to implement additional properties or methods. If needed, you can always add properties and/or methods like `VuetablePaginationDropdown` did.

### Uses
- [VuetablePaginationMixin](VuetablePaginationMixin)

